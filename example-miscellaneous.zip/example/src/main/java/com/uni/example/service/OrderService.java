package com.uni.example.service;

import com.uni.example.restaurant.model.Order;

public interface OrderService {
public void saveOrder(Order o);
}
